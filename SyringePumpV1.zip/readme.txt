Syringe Pump V1.0

Cheap and easy to make, if you have a 3D printer, anyway.

Still has some things I want to work on but it's fully functional as is.

Runs from an Ardunio Uno and a GShield. Should be easily modified for other similar boards.

Ran through a serial interface. The one in the Arduino IDE works fine. 

Type a ? for a list of the available commands.

Always Home the syringe before performing any other movements.
